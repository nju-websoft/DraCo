# -*- coding: utf-8 -*-


class RequestContentType:
    FormData = 'multipart/form-data'
    Json = 'application/json'
