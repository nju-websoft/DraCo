# -*- coding: utf-8 -*-
from a3faker import FakerProxy


f = FakerProxy.get_faker()
