# -*- coding: utf-8 -*-
from .base_post_view import BasePostView, DynamicResponseStruct
