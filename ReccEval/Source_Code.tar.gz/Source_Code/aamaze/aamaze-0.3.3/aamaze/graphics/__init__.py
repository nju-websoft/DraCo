import os

import pygame

from .app import GraphicsApp
from .draw_maze import DrawMaze

os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"

pygame.init()
