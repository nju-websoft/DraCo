from adaptix._internal.provider.static_provider import StaticProvider, static_provision_action

__all__ = (
    'StaticProvider',
    'static_provision_action',
)
