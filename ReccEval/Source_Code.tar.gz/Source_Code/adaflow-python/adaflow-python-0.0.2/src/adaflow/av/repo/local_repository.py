
class LocalRepository:
    pass


