# -*- coding: utf-8 -*-
"""
@desc: 
@author: 1nchaos
@time:2023/4/5
@log: 
"""


class BondMarket(object):
    """bond 行情"""

    def __init__(self) -> None:
        super().__init__()
