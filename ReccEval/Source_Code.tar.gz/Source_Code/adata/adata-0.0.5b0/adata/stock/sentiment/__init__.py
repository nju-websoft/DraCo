# -*- coding: utf-8 -*-
"""
@desc: 新闻舆情相关的数据
@author: 1nchaos
@time:2023/04/06
@log: 
"""
