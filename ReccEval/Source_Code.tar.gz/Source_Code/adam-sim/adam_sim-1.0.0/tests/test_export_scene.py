from adam_sim import Adam


def main():
    Adam.export_scene('tests/')


if __name__ == '__main__':
    main()
    