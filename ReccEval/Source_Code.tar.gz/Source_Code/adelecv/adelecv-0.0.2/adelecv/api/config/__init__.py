from .default import Settings

__all__ = [
    "Settings",
]
