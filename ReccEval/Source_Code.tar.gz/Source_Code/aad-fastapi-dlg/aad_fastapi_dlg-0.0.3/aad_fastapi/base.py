NAME = "aad_fastapi"
